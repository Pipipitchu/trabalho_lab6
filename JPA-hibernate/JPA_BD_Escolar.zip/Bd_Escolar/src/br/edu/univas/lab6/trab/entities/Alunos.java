package br.edu.univas.lab6.trab.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

@Entity
public class Alunos {
	@Id
	@GeneratedValue ( strategy = GenerationType . SEQUENCE ,
	generator ="seq_alu_1")

	@SequenceGenerator ( name ="seq_alu_1",

	 sequenceName ="SEQ_ALU_1",

	 allocationSize =1)
	private int cod;
	private String nome;
	private String sexo;
	private int idade;
	private String n_mae;
	private String cidade;
	private String estado;
	private String pais;
	private String intercambio;
	private int t_intercambio;
	private int ano;
	private String repetente;
	private int qtd_rep;
	private String transferido;
	private String bolsista;
	private String fies;
	private String pne;
	@OneToOne(mappedBy="Materias_Incl")
	private int grade;
	
	public int getCod() {
		return cod;
	}
	public void setCod(int cod) {
		this.cod = cod;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getSexo() {
		return sexo;
	}
	public void setSexo(String sexo) {
		this.sexo = sexo;
	}
	public int getIdade() {
		return idade;
	}
	public void setIdade(int idade) {
		this.idade = idade;
	}
	public String getN_mae() {
		return n_mae;
	}
	public void setN_mae(String n_mae) {
		this.n_mae = n_mae;
	}
	public String getCidade() {
		return cidade;
	}
	public void setCidade(String cidade) {
		this.cidade = cidade;
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	public String getPais() {
		return pais;
	}
	public void setPais(String pais) {
		this.pais = pais;
	}
	public String getIntercambio() {
		return intercambio;
	}
	public void setIntercambio(String intercambio) {
		this.intercambio = intercambio;
	}
	public int getT_intercambio() {
		return t_intercambio;
	}
	public void setT_intercambio(int t_intercambio) {
		this.t_intercambio = t_intercambio;
	}
	public int getAno() {
		return ano;
	}
	public void setAno(int ano) {
		this.ano = ano;
	}
	public String getRepetente() {
		return repetente;
	}
	public void setRepetente(String repetente) {
		this.repetente = repetente;
	}
	public int getQtd_rep() {
		return qtd_rep;
	}
	public void setQtd_rep(int qtd_rep) {
		this.qtd_rep = qtd_rep;
	}
	public String getTransferido() {
		return transferido;
	}
	public void setTransferido(String transferido) {
		this.transferido = transferido;
	}
	public String getBolsista() {
		return bolsista;
	}
	public void setBolsista(String bolsista) {
		this.bolsista = bolsista;
	}
	public String getFies() {
		return fies;
	}
	public void setFies(String fies) {
		this.fies = fies;
	}
	public String getPne() {
		return pne;
	}
	public void setPne(String pne) {
		this.pne = pne;
	}
	public int getGrade() {
		return grade;
	}
	public void setGrade(int grade) {
		this.grade = grade;
	}

}
