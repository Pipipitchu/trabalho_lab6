package br.edu.univas.lab6.trab.DAO;

import javax.persistence.EntityManager;

import br.edu.univas.lab6.trab.entities.Materias_Incl;

public class Materias_InclDAO extends GenericDAO<Materias_Incl, Integer> {

	public Materias_InclDAO(EntityManager em) {
		super(em);
		// TODO Auto-generated constructor stub
	}

}
