package br.edu.univas.lab6.trab.DAO;

import javax.persistence.EntityManager;

import br.edu.univas.lab6.trab.entities.Alunos;

public class AlunosDAO extends GenericDAO<Alunos, Integer> {

	public AlunosDAO(EntityManager em) {
		super(em);
		// TODO Auto-generated constructor stub
	}

}
