package br.edu.univas.lab6.trab.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
public class Professores {
	@Id
	@GeneratedValue ( strategy = GenerationType . SEQUENCE ,
	generator ="seq_prof")

	@SequenceGenerator ( name ="seq_prof",

	 sequenceName ="SEQ_PROF",

	 allocationSize =1)
	private int cod;
	private String nome;
	private String sexo;
	private String cidade;
	private String estado; 
	private String pais;
	private String estado_civil;
	private String graduacao;
	private String instituicao;
	private String especializao;
	private String area;
	private int m_principal;
	private int m_secundaria;
	public int getCod() {
		return cod;
	}
	public void setCod(int cod) {
		this.cod = cod;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getSexo() {
		return sexo;
	}
	public void setSexo(String sexo) {
		this.sexo = sexo;
	}
	public String getCidade() {
		return cidade;
	}
	public void setCidade(String cidade) {
		this.cidade = cidade;
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	public String getPais() {
		return pais;
	}
	public void setPais(String pais) {
		this.pais = pais;
	}
	public String getEstado_civil() {
		return estado_civil;
	}
	public void setEstado_civil(String estado_civil) {
		this.estado_civil = estado_civil;
	}
	public String getGraduacao() {
		return graduacao;
	}
	public void setGraduacao(String graduacao) {
		this.graduacao = graduacao;
	}
	public String getInstituicao() {
		return instituicao;
	}
	public void setInstituicao(String instituicao) {
		this.instituicao = instituicao;
	}
	public String getEspecializao() {
		return especializao;
	}
	public void setEspecializao(String especializao) {
		this.especializao = especializao;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public int getM_principal() {
		return m_principal;
	}
	public void setM_principal(int m_principal) {
		this.m_principal = m_principal;
	}
	public int getM_secundaria() {
		return m_secundaria;
	}
	public void setM_secundaria(int m_secundaria) {
		this.m_secundaria = m_secundaria;
	}
	
}
