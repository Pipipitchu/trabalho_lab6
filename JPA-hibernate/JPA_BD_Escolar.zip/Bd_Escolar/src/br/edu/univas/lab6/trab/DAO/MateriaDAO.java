package br.edu.univas.lab6.trab.DAO;

import javax.persistence.EntityManager;

import br.edu.univas.lab6.trab.entities.Materia;

public class MateriaDAO extends GenericDAO<Materia, Integer> {

	public MateriaDAO(EntityManager em) {
		super(em);
		// TODO Auto-generated constructor stub
	}

}
