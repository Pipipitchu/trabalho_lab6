package br.edu.univas.lab6.trab.DAO;

import javax.persistence.EntityManager;

import br.edu.univas.lab6.trab.entities.Grade_2;

public class Grade_2DAO extends GenericDAO<Grade_2, Integer> {

	public Grade_2DAO(EntityManager em) {
		super(em);
		// TODO Auto-generated constructor stub
	}

}
