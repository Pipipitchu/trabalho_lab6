package br.edu.univas.lab6.trab.DAO;

import javax.persistence.EntityManager;

import br.edu.univas.lab6.trab.entities.Professores;

public class ProfessoresDAO extends GenericDAO<Professores, Integer> {

	public ProfessoresDAO(EntityManager em) {
		super(em);
		// TODO Auto-generated constructor stub
	}

}
