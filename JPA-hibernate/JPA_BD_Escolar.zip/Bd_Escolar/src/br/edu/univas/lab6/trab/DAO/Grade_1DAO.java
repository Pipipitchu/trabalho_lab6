package br.edu.univas.lab6.trab.DAO;

import javax.persistence.EntityManager;

import br.edu.univas.lab6.trab.entities.Grade_1;

public class Grade_1DAO extends GenericDAO<Grade_1, Integer> {

	public Grade_1DAO(EntityManager em) {
		super(em);
		// TODO Auto-generated constructor stub
	}

}
