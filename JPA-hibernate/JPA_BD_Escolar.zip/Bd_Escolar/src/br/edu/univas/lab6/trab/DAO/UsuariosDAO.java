package br.edu.univas.lab6.trab.DAO;

import javax.persistence.EntityManager;

import br.edu.univas.lab6.trab.entities.Usuarios;

public class UsuariosDAO extends GenericDAO<Usuarios, Integer> {

	public UsuariosDAO(EntityManager em) {
		super(em);
		// TODO Auto-generated constructor stub
	}

}
