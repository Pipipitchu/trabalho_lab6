package br.edu.univas.lab6.trab.entities;

import java.io.Serializable;

public class Notas_1PK implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private int cod;
	private int bimestre;
	private int ano;
	private int aluno;
	private int materia;

	public Notas_1PK(){
        // Your class must have a no-arq constructor
    }
	
	@Override
    public boolean equals(Object obj) {
        if(obj instanceof Notas_1PK){
        	Notas_1PK carPk = (Notas_1PK) obj;
 
            if(!(carPk.getCod()==cod)){
                return false;
            }
 
            if(!(carPk.getBimestre()==bimestre)){
                return false;
            }
            if(!(carPk.getAno()==ano)){
                return false;
            }
            if(!(carPk.getAluno()==aluno)){
                return false;
            }
            if(!(carPk.getMateria()==materia)){
                return false;
            }
 
            return true;
        }
 
        return false;
    }
	
	public int getCod() {
		return cod;
	}

	public void setCod(int cod) {
		this.cod = cod;
	}

	public int getBimestre() {
		return bimestre;
	}

	public void setBimestre(int bimestre) {
		this.bimestre = bimestre;
	}

	public int getAno() {
		return ano;
	}

	public void setAno(int ano) {
		this.ano = ano;
	}

	public int getAluno() {
		return aluno;
	}

	public void setAluno(int aluno) {
		this.aluno = aluno;
	}

	public int getMateria() {
		return materia;
	}

	public void setMateria(int materia) {
		this.materia = materia;
	}
}
