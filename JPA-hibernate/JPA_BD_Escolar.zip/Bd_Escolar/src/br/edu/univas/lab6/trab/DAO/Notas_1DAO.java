package br.edu.univas.lab6.trab.DAO;

import javax.persistence.EntityManager;

import br.edu.univas.lab6.trab.entities.Notas_1;

public class Notas_1DAO extends GenericDAO<Notas_1, Integer> {

	public Notas_1DAO(EntityManager em) {
		super(em);
		// TODO Auto-generated constructor stub
	}

}
